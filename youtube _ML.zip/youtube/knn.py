import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier

# Caricamento del dataset
file_path = 'youtube_standard.csv'
data = pd.read_csv(file_path)

# Rimozione delle colonne non numeriche
X = data.drop(['Like_View_Ratio_Category', 'Title', 'Publish_Date','Duration'], axis=1)
y = data['Like_View_Ratio_Category']

# Addestramento del modello Random Forest
rf = RandomForestClassifier(random_state=42)
rf.fit(X, y)

# Ottenere l'importanza delle caratteristiche
importances = rf.feature_importances_

# Visualizzazione dell'importanza delle caratteristiche
feature_importances = pd.Series(importances, index=X.columns)
plt.figure(figsize=(10, 6))
feature_importances.nlargest(len(X.columns)).plot(kind='barh')
plt.title("Importanza delle Caratteristiche nel Modello Random Forest")
plt.xlabel("Importanza della Caratteristica")
plt.ylabel("Caratteristiche")
plt.show()
