import pandas as pd
from datetime import datetime
import pytz
# Funzione per convertire la durata del video in formato ISO 8601 in secondi
def convert_duration_to_seconds_iso(duration_str):
    return pd.to_timedelta(duration_str).total_seconds()

# Carica il dataset originale
file_path_new = 'youtube_videos_info.csv'  # Sostituisci con il percorso del tuo file
youtube_data_new = pd.read_csv(file_path_new)

# Converti la colonna della data in datetime tz-aware
youtube_data_new['Publish_Date'] = pd.to_datetime(youtube_data_new['Publish_Date'])

# Imposta data_attuale come tz-aware nel fuso orario UTC
data_attuale = datetime.now(pytz.utc)

# Calcola l'età del video
youtube_data_new['video_age'] = youtube_data_new['Publish_Date'].apply(lambda x: (data_attuale - x).days)

# Conversione della durata del video in secondi
youtube_data_new['Duration_Seconds'] = youtube_data_new['Duration'].apply(convert_duration_to_seconds_iso)

# Calcolo del rapporto commenti/visualizzazioni
youtube_data_new['Comment_View_Ratio'] = youtube_data_new['Comment_Count'] / youtube_data_new['Views']

# Calcolo del rapporto like/visualizzazioni
youtube_data_new['Like_View_Ratio'] = youtube_data_new['Likes'] / youtube_data_new['Views']

#Creazione della variabile target di classificazione in 8 categorie
youtube_data_new['Like_View_Ratio_Category'] = pd.qcut(youtube_data_new['Like_View_Ratio'], 8, labels=False)

# Salvataggio del dataset trasformato in un nuovo file CSV
transformed_file_path = 'youtube_updated.csv'  # Sostituisci con il percorso desiderato per il nuovo file
youtube_data_new.to_csv(transformed_file_path, index=False)

