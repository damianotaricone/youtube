import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

# Caricamento del dataset standardizzato e senza outlier
# Assicurati di usare il dataset corretto qui
df = pd.read_csv('youtube_standard.csv')

# Selezionare le feature e il target
X = df[['video_age', 'Duration_Seconds', 'Views','Comment_View_Ratio']]
y = df['Like_View_Ratio_Category']

# Divisione in set di addestramento e di test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalizzazione delle feature
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Creazione ed addestramento del modello KNN
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_scaled, y_train)
predictions_knn = knn.predict(X_test_scaled)
accuracy_knn = accuracy_score(y_test, predictions_knn)

# Creazione ed addestramento del modello Random Forest
rf_model = RandomForestClassifier(n_estimators=600, random_state=42)
rf_model.fit(X_train_scaled, y_train)
predictions_rf = rf_model.predict(X_test_scaled)
accuracy_rf = accuracy_score(y_test, predictions_rf)

# Creazione ed addestramento del modello SVM
svm_model = SVC(kernel='rbf')
svm_model.fit(X_train_scaled, y_train)
predictions_svm = svm_model.predict(X_test_scaled)
accuracy_svm = accuracy_score(y_test, predictions_svm)

# Creazione ed addestramento del modello di regressione logistica
log_reg = LogisticRegression()
log_reg.fit(X_train_scaled, y_train)
predictions_lr = log_reg.predict(X_test_scaled)
accuracy_lr = accuracy_score(y_test, predictions_lr)

# Creazione ed addestramento del modello Naive Bayes
nb_model = GaussianNB()
nb_model.fit(X_train_scaled, y_train)
predictions_nb = nb_model.predict(X_test_scaled)
accuracy_nb = accuracy_score(y_test, predictions_nb)

# Creazione ed addestramento del modello Gradient Boosting
gb_model = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1)
gb_model.fit(X_train_scaled, y_train)
predictions_gb = gb_model.predict(X_test_scaled)
accuracy_gb = accuracy_score(y_test, predictions_gb)

# Stampa delle accuratezze
print(f"K-Nearest Neighbors Accuracy: {accuracy_knn}")
print(f"Random Forest Accuracy: {accuracy_rf}")
print(f"SVM Accuracy: {accuracy_svm}")
print(f"Logistic Regression Accuracy: {accuracy_lr}")
print(f"Naive Bayes Accuracy: {accuracy_nb}")
print(f"Gradient Boosting Accuracy: {accuracy_gb}")

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

'''

# Parametri per Grid Search del RandomForestClassifier
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_features': ['sqrt', 'log2', None],  # Modificato qui
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

# Creazione del modello Random Forest
rf = RandomForestClassifier(random_state=42)

# Grid Search
grid_search_rf = GridSearchCV(estimator=rf, param_grid=param_grid_rf, cv=3, n_jobs=-1, verbose=2)
grid_search_rf.fit(X_train_scaled, y_train)
best_grid_rf = grid_search_rf.best_estimator_

# Parametri per Random Search
# Parametri per Random Search del RandomForestClassifier
param_distributions_rf = {
    'n_estimators': [int(x) for x in np.linspace(start=100, stop=1000, num=10)],
    'max_features': ['sqrt', 'log2', None],  # Modificato qui
    'max_depth': [int(x) for x in np.linspace(10, 110, num=11)] + [None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

# Random Search
random_search_rf = RandomizedSearchCV(estimator=rf, param_distributions=param_distributions_rf, n_iter=100, cv=3, verbose=2, random_state=42, n_jobs=-1)
random_search_rf.fit(X_train_scaled, y_train)
best_random_rf = random_search_rf.best_estimator_


# Per Random Forest
best_params_rf = grid_search_rf.best_params_
print("Migliori parametri per Random Forest:", best_params_rf)

best_score_rf = grid_search_rf.best_score_
print("Miglior punteggio per Random Forest:", best_score_rf)

best_model_rf = grid_search_rf.best_estimator_


best_params_random = random_search_rf.best_params_  # Sostituisci 'random_search' con il nome effettivo
print("Migliori parametri (Random Search):", best_params_random)
best_score_random = random_search_rf.best_score_  # Sostituisci 'random_search' con il nome effettivo
print("Miglior punteggio (Random Search):", best_score_random)
best_model_random = random_search_rf.best_estimator_  # Sostituisci 'random_search' con il nome effettivo

'''

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import cross_val_score

# Addestramento con i parametri del Grid Search
rf_grid = RandomForestClassifier(max_depth= 30, max_features= "sqrt", min_samples_leaf= 1, min_samples_split= 2, n_estimators=300, random_state=42)
rf_grid.fit(X_train_scaled, y_train)
predictions_grid = rf_grid.predict(X_test_scaled)

# Addestramento con i parametri del Random Search
rf_random = RandomForestClassifier(max_depth=20, max_features='sqrt', min_samples_leaf=1, min_samples_split=2, n_estimators=1000, random_state=42)
rf_random.fit(X_train_scaled, y_train)
predictions_random = rf_random.predict(X_test_scaled)

# Valutazione delle prestazioni
def evaluate_model(model, X_test, y_test, predictions):
    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, average='macro')
    recall = recall_score(y_test, predictions, average='macro')
    f1 = f1_score(y_test, predictions, average='macro')
    print(f"Accuracy: {accuracy}\nPrecision: {precision}\nRecall: {recall}\nF1 Score: {f1}")

    # Valutazione tramite cross-validation
    cv_scores = cross_val_score(model, X_test, y_test, cv=5)
    print(f"Cross-Validation Scores: {cv_scores}")
    print(f"Mean CV Score: {np.mean(cv_scores)}")

# Valutazione del modello Grid Search
print("\nPerformance del modello Random Forest (Grid Search):")
evaluate_model(rf_grid, X_test_scaled, y_test, predictions_grid)

# Valutazione del modello Random Search
print("\nPerformance del modello Random Forest (Random Search):")
evaluate_model(rf_random, X_test_scaled, y_test, predictions_random)

# Valutazione del modello Random Search
print("\nPerformance del modello Random Forest INIZIALE:")
evaluate_model(rf_model, X_test_scaled, y_test,predictions_rf)


from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier

# I tuoi dati di addestramento e test scalati sono già definiti come X_train_scaled, X_test_scaled, y_train, y_test

# Definizione dei modelli base con random_state impostato
base_learners = [
    ('rf_model', RandomForestClassifier(n_estimators= 600, random_state=42)),
    ('knn_model', KNeighborsClassifier()),
    ('svc_model', SVC(probability=True, random_state=42)),
    ('dt_model', DecisionTreeClassifier(random_state=42))
]

# Meta-classificatore
meta_learner = LogisticRegression(random_state=42)

# Modello di Stacking
stacking_classifier = StackingClassifier(estimators=base_learners, final_estimator=meta_learner, cv=5)

# Addestramento del modello di Stacking
stacking_classifier.fit(X_train_scaled, y_train)

# Facciamo le previsioni usando il modello di Stacking
predictions_stack = stacking_classifier.predict(X_test_scaled)

# Calcoliamo l'accuratezza del modello di Stacking
accuracy_stack = accuracy_score(y_test, predictions_stack)

print(f"\nL'accuratezza del modello di Random Forest è: {accuracy_rf:.2f}")


from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.model_selection import cross_val_score

# Calcolo delle metriche aggiuntive per il modello di Stacking
precision_stack = precision_score(y_test, predictions_stack, average='macro')
recall_stack = recall_score(y_test, predictions_stack, average='macro')
f1_score_stack = f1_score(y_test, predictions_stack, average='macro')

# Calcolo dei cross-validation scores per il modello di Stacking
cv_scores_stack = cross_val_score(stacking_classifier, X_train_scaled, y_train, cv=5)
mean_cv_score_stack = cv_scores_stack.mean()

# Stampa dei risultati
print(f"\nL'accuratezza del modello di Stacking è: {accuracy_stack:.2f}")
print(f"Precisione del modello di Stacking: {precision_stack:.2f}")
print(f"Ricordo del modello di Stacking: {recall_stack:.2f}")
print(f"F1 Score del modello di Stacking: {f1_score_stack:.2f}")
print(f"Cross-Validation Scores del modello di Stacking: {cv_scores_stack}")
print(f"Media Cross-Validation Score del modello di Stacking: {mean_cv_score_stack:.2f}")

from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Supponendo che tu abbia già le variabili predictions_stack e y_test
cm = confusion_matrix(y_test, predictions_stack)

# Visualizzazione della matrice di confusione
plt.figure(figsize=(10, 7))
sns.heatmap(cm, annot=True, fmt='g')
plt.title('\nMatrice di Confusione')
plt.ylabel('Verità Effettiva')
plt.xlabel('Previsione del Modello')
plt.show()


from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Parametri da ottimizzare per RandomForest
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10]
}

# Creazione del GridSearchCV per RandomForest
grid_rf = GridSearchCV(RandomForestClassifier(random_state=42), param_grid_rf, cv=5, n_jobs=-1, verbose=1)
grid_rf.fit(X_train, y_train)
best_rf = grid_rf.best_estimator_

# Parametri da ottimizzare per SVC
param_grid_svc = {
    'C': [0.1, 1, 10],
    'gamma': ['scale', 'auto'],
    'kernel': ['rbf', 'linear']
}

# Creazione del GridSearchCV per SVC
grid_svc = GridSearchCV(SVC(probability=True, random_state=42), param_grid_svc, cv=5, n_jobs=-1, verbose=1)
grid_svc.fit(X_train, y_train)
best_svc = grid_svc.best_estimator_

# Definizione dei modelli base con i modelli ottimizzati
base_learners = [
    ('rf_model', best_rf),
    ('svc_model', best_svc),
    ('knn_model', KNeighborsClassifier()),
    ('dt_model', DecisionTreeClassifier(random_state=42))
]

# Meta-classificatore
meta_learner = LogisticRegression(random_state=42)

# Modello di Stacking
stacking_classifier = StackingClassifier(estimators=base_learners, final_estimator=meta_learner, cv=5)

# Addestramento del modello di Stacking
stacking_classifier.fit(X_train, y_train)

# Facciamo le previsioni usando il modello di Stacking
predictions_stack = stacking_classifier.predict(X_test)

# Calcoliamo l'accuratezza del modello di Stacking
accuracy_stack = accuracy_score(y_test, predictions_stack)

# Calcolo delle metriche aggiuntive per il modello di Stacking
precision_stack = precision_score(y_test, predictions_stack, average='macro')
recall_stack = recall_score(y_test, predictions_stack, average='macro')
f1_score_stack = f1_score(y_test, predictions_stack, average='macro')

# Calcolo dei cross-validation scores per il modello di Stacking
cv_scores_stack = cross_val_score(stacking_classifier, X_train_scaled, y_train, cv=5)
mean_cv_score_stack = cv_scores_stack.mean()

# Stampa dei risultati
print(f"\nL'accuratezza del modello di Stacking è: {accuracy_stack:.2f}")
print(f"Precisione del modello di Stacking: {precision_stack:.2f}")
print(f"Ricordo del modello di Stacking: {recall_stack:.2f}")
print(f"F1 Score del modello di Stacking: {f1_score_stack:.2f}")
print(f"Cross-Validation Scores del modello di Stacking: {cv_scores_stack}")
print(f"Media Cross-Validation Score del modello di Stacking: {mean_cv_score_stack:.2f}")