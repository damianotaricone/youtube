import pandas as pd
import numpy as np

# Carica il dataset originale
file_path_new = 'youtube_updated.csv'  # Sostituisci con il percorso del tuo file CSV
youtube_data = pd.read_csv(file_path_new)

print(youtube_data)

# Definisci la funzione per aggiungere rumore gaussiano
def add_gaussian_noise(series, noise_level):
    return series + np.random.normal(0, noise_level, size=len(series))

# Scegli le colonne numeriche a cui desideri aggiungere rumore
numeric_columns = ['Likes', 'Views', 'Comment_View_Ratio', 'Duration_Seconds']  # Modifica con le colonne del tuo dataset
noise_level = 0.05  # Imposta il livello di rumore desiderato

# Crea una copia del dataset per l'augmentation
augmented_data = youtube_data.copy()

# Aggiungi rumore gaussiano
for column in numeric_columns:
    augmented_data[column] = add_gaussian_noise(augmented_data[column], noise_level * augmented_data[column].std())

# Concatena il dataset originale con quello augmentato
augmented_dataset = pd.concat([youtube_data, augmented_data])

print(augmented_dataset)

# Salva il dataset aumentato in un nuovo file CSV
augmented_file_path = 'youtube_augmented.csv'  # Sostituisci con il percorso desiderato per il nuovo file
augmented_dataset.to_csv(augmented_file_path, index= True)

augmented_file_path
