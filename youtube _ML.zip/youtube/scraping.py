from googleapiclient.discovery import build
import youtube_dl

# Configurazione dell'API
youtube_api_key = 'youtube_api_key'
youtube = build('youtube', 'v3', developerKey=youtube_api_key)

channel_id = 'UCaQ5jBalt_0jlerj29gy9NQ'

# Funzione per ottenere gli ID dei video di un canale
def get_video_ids(youtube, channel_id):
    video_ids = []
    next_page_token = None

    while True:
        request = youtube.search().list(
            part='id',
            channelId=channel_id,
            maxResults=50,
            pageToken=next_page_token,
            type='video'
        )
        response = request.execute()

        video_ids += [item['id']['videoId'] for item in response['items']]

        next_page_token = response.get('nextPageToken')
        if next_page_token is None:
            break

    return video_ids


def get_youtube_video_info(api_key, video_id):
    # Configurazione del client API di YouTube
    youtube = build('youtube', 'v3', developerKey=api_key)

    # Richiesta all'API di YouTube
    request = youtube.videos().list(
        part="snippet,statistics,contentDetails",
        id=video_id
    )
    response = request.execute()

    # Controllo se il video è stato trovato e estrazione dei dati
    if response['items']:
        video_data = response['items'][0]
        info = {
            'title': video_data['snippet']['title'],
            'publish_date': video_data['snippet']['publishedAt'],
            'likes': video_data['statistics'].get('likeCount', 'N/A'),
            'views': video_data['statistics'].get('viewCount', 'N/A'),
            'duration': video_data['contentDetails']['duration'],
            'comment_count': video_data['statistics'].get('commentCount', 'N/A')
        }
        return info
    else:
        return "Video non trovato."




# Ottenere gli ID dei video
video_ids = get_video_ids(youtube, channel_id)
api_key = 'AIzaSyD8U9vEvEExAuLIq6PUZ6vUj_IgGC8-sz0'  # Sostituisci con la tua chiave API


import csv

# Nome del file CSV di output
output_file = 'youtube_videos_info.csv'

# Creazione e apertura del file CSV
with open(output_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)

    # Scrivi l'intestazione del file CSV
    writer.writerow(['Title', 'Publish_Date', 'Likes', 'Views', 'Duration', 'Comment_Count'])

    # Itera attraverso la lista degli ID dei video e scrivi i dati nel CSV
    for video_id in video_ids:
        video_info = get_youtube_video_info(api_key, video_id)
        if isinstance(video_info, dict):  # Verifica che le informazioni siano state trovate
            writer.writerow([video_info['title'], video_info['publish_date'], video_info['likes'],
                             video_info['views'], video_info['duration'], video_info['comment_count']])
        else:
            print(f"Video {video_id} non trovato.")