import pandas as pd
from scipy import stats
import numpy as np
import matplotlib.pyplot as plt

# Caricamento del dataset
file_path = 'youtube_augmented.csv'  # Sostituisci con il percorso del tuo file
data = pd.read_csv(file_path)

# Colonne da standardizzare e confrontare
columns_to_standardize = ['Likes', 'Views', 'video_age', 'Duration_Seconds']

# Applicazione della standardizzazione Z-score
data_standardized = data.copy()
data_standardized[columns_to_standardize] = stats.zscore(data[columns_to_standardize])

# Rimozione degli outlier (valori oltre 3 deviazioni standard dalla media)
data_no_outliers = data_standardized[(np.abs(stats.zscore(data_standardized[columns_to_standardize])) < 3).all(axis=1)]

# Preparazione dei boxplot per confronto
fig, axs = plt.subplots(len(columns_to_standardize), 2, figsize=(15, 10))

for i, col in enumerate(columns_to_standardize):
    # Boxplot prima della standardizzazione
    axs[i, 0].boxplot(data[col].dropna())
    axs[i, 0].set_title(f'Boxplot di {col} (Prima della Standardizzazione)')
    axs[i, 0].set_ylabel('Valori')

    # Boxplot dopo la standardizzazione e rimozione degli outlier
    axs[i, 1].boxplot(data_no_outliers[col].dropna())
    axs[i, 1].set_title(f'Boxplot di {col} (Dopo Standardizzazione e Rimozione Outlier)')
    axs[i, 1].set_ylabel('Valori Scalati')

# Ajustamento dell'layout per evitare sovrapposizioni
plt.tight_layout()
plt.show()

# Salvataggio del dataset in un nuovo file CSV
new_file_path = 'youtube_standard.csv'  # Sostituisci con il percorso dove vuoi salvare il file
data_no_outliers.to_csv(new_file_path, index=False)
